//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : comms.h                                                    //
// Date            : 04/06/2019                                                 //
// Author          : Communications Team                                        //
// Copyright       : (c) 2019, Communications Team, Mentor: Dr. Jason Losh,     //
//                   The University of Texas at Arlington.                      //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 1.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// This Software was made under the guidance of Dr. Jason Losh,                 //
// The University of Texas at Arlington. Any UNAUTHORIZED use of this software, //
// without the prior permission and consent of Dr. Jason Losh or any of the,    //
// mentioned contributors is a direct violation of Copyright.                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES BE LIABLE FOR,    //
// SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER.      //
//                                                                              //
//******************************************************************************//


#ifndef __COMMS_H
#define __COMMS_H



//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//


#include <tm4c123gh6pm.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>


//*****************************************************************************//
//                                                                             //
//                   EXTERN VARIABLES AND STRUCTURES                           //
//                                                                             //
//*****************************************************************************//


//********************************* Global Scope ***********************************//


// TODO make this typedef :receiveMessageTypdef, make members all caps and change code in .c file accordingly
struct uartRecv
{
    char     message[36];
    uint8_t  checksum;
    uint8_t  rSlotNum;
    uint16_t rSlotTime;

}recvMessage;



// Structure for processing join request
typedef struct joinRequestMessage
{
    uint8_t PREAMBLE[4];
    uint8_t NID[4];
    uint8_t MAC[6];
    uint8_t SLOT[2];

}joinRequestType;

extern joinRequestType joinRequest;


//*********************************** Receive Message variables **************************************//


// Receive variables and buffers for receive message arguments
extern uint16_t rNetworkID;                  //!< Read received Network ID from network.
extern uint8_t  rNetworkSlotNumber;          //!< Read slot number assigned by the network
extern char     rMacAddr[6];                 //!< Read this variable to get the value of MAC address


// For RTC Time and Date receive variables
extern uint8_t Hours;
extern uint8_t Minutes;
extern uint8_t Seconds;

extern uint8_t Year;
extern uint8_t Month;
extern uint8_t Day;


// Flags
extern uint8_t syncMesssageFlag;             //!< This Flag is set whenever sync is received
extern uint8_t joinRequestFlag;              //!< Enable this Flag, to get access slot for sending join request
extern uint8_t joinResponseFlag;             //!< This Flag is set whenever a join response is received
extern uint8_t networkJoinedFlag;            //!< This Flag is set whenever network is joined
extern uint8_t statusRecvFlag;               //!< This Flag is set whenever status message is received
extern uint8_t timeOutFlag;                  //!< This Flag is set whenever sync message times out.




//*****************************************************************************//
//                                                                             //
//                          Function Prototypes                                //
//                                                                             //
//*****************************************************************************//



// Function for Initialing Communication module
// retval : none
// args   : none
void initComm(void);


// Blocking Function for sending Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3)
// retval : none
// args   : Character Data (8-BIT) value
void sendData(const char data);


// Blocking Function for sending Stream of Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3), with checksum.
// retval : none
// args   : Data Stream / String value
void sendStream(char* data);


// Function for Receiving data from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Character Data (8-Bit)
// args   : none
char recvData(void);


// Function for Receiving data stream from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Signed Integer (8-Bit), 0: Success, -1: Fail, Checksum Error
// args   : String buffer to store data.
int8_t recvStream(char* buffer);



#endif

