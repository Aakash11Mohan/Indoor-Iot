//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : syncgen.c                                                  //
// Date            : 03/22/2019                                                 //
// Author          : Communications Team                                        //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 2.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
// Hardware configuration:                                                      //
//                                                                              //
//                                                                              //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// CONTRIBUTORS: Aditya Mall, Murilo Pinheiro, Murtaza Baj,                     //
//               Bisruth Subedi, Sanjeevni Chaudhari, Aakash Mohan,             //
//               Kashish Shah.                                                  //
//                                                                              //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//                                                                              //
//******************************************************************************//




//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//



#include "headers.h"



//*****************************************************************************//
//                                                                             //
//                          GLOBAL VARIABLES                                   //
//                                                                             //
//*****************************************************************************//




// ISR variables
uint32_t isrDelay = 0;



//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//

void initHw()
{
    //******************************************************* Clock Configs ******************************************************************//

    // Configure System clock as 40Mhz
    SYSCTL_RCC_R = SYSCTL_RCC_XTAL_16MHZ | SYSCTL_RCC_OSCSRC_MAIN | SYSCTL_RCC_USESYSDIV | (0x04 << SYSCTL_RCC_SYSDIV_S);

    // Enable GPIO port A, and F peripherals
    SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOA | SYSCTL_RCGC2_GPIOF | SYSCTL_RCGC2_GPIOC;



    //**************************************************** On Board Modules ******************************************************************//

    // Configure On boards RED, GREEN and BLUE led and Pushbutton Pins
    GPIO_PORTF_DEN_R |= (1 << 1) | (1 << 2) | (1 << 3) | (1 << 4);                  // Enable Digital
    GPIO_PORTF_DIR_R |= (1 << 1) | (1 << 2) | (1 << 3);                             // Enable as Output
    GPIO_PORTF_DIR_R &= ~(0x10);                                                    // Enable push button as Input
    GPIO_PORTF_PUR_R |= 0x10;                                                       // Enable internal pull-up for push button

    // GPIO Interrupt
    GPIO_PORTF_IM_R |= 0x10;
    NVIC_EN0_R |= (1<<(INT_GPIOF-16));

}


// Wide Timer ISR with Match
void initWTimer5(void)
{
    SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R5;                                       // turn-on timer
    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;                                                  // turn-off counter before reconfiguring
    WTIMER5_CFG_R  = 4;                                                                // configure as 32-bit counter (A only)

    WTIMER5_TAMR_R = TIMER_TAMR_TAMR_1_SHOT | TIMER_TAMR_TACDIR | TIMER_TAMR_TAMIE;    // 1-Shot mode, Count up, Match interrupt Enable
    WTIMER5_TAMATCHR_R = (40000 * (slotTime * (numOfSlots + 1)) ) - 1;                 // slotTime & numOfSlot defined in messageHandle.c

    NVIC_EN3_R |= 1 << (INT_WTIMER5A-16-96);                                           // Enable interrupt in NVIC
    WTIMER5_IMR_R = TIMER_IMR_TAMIM;                                                   // Match Interrupt Enable

    WTIMER5_CTL_R |= TIMER_CTL_TAEN;                                                   // Initial Start of Timer
}


//
//
//
void gpioPortFIsr(void)
{
    joinRespButton = 1;
    responseFlag   = 1;           // enable this to parse the join request


    GPIO_PORTF_ICR_R = 0x10;
}



// TX ISR
void wTimer5Isr(void)
{

    if(joinAckFlag == 0)
    {
        syncMessageSend();
        ONBOARD_GREEN_LED ^= 1;
        ONBOARD_BLUE_LED   = 0;
        ONBOARD_RED_LED    = 0;

    }

    if(joinAckFlag == 1 && joinRespButton == 1)
    {
        //send join response message
        joinResponseMessageSend();


        // Update the ISR to send sync message in the next iteration
        WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;
        WTIMER5_TAMATCHR_R = (40000 * (slotTime * (numOfSlots + 1)) ) - 1;              // slotTime & numOfSlot defined in messageHandle.c
        WTIMER5_CTL_R |= TIMER_CTL_TAEN;
        WTIMER5_TAV_R = 0;

        ONBOARD_BLUE_LED   = 0;
        ONBOARD_GREEN_LED ^= 1;
        ONBOARD_RED_LED  ^= 1;


    }

    // Status LED (Optional, but good to have this)


    // Clear Interrupt
    WTIMER5_ICR_R = TIMER_ICR_TAMCINT;
    WTIMER5_TAV_R = 0;

}



// micro second delay function
void waitMicrosecond(uint32_t us)
{
    __asm("WMS_LOOP0:   MOV  R1, #6"       );
    __asm("WMS_LOOP1:   SUB  R1, #1"       );
    __asm("             CBZ  R1, WMS_DONE1");
    __asm("             NOP"               );
    __asm("             NOP"               );
    __asm("             B    WMS_LOOP1"    );
    __asm("WMS_DONE1:   SUB  R0, #1"       );
    __asm("             CBZ  R0, WMS_DONE0");
    __asm("             NOP"               );
    __asm("             B    WMS_LOOP0"    );
    __asm("WMS_DONE0:"                     );
}




// Sender - Broadcast
int main(void)
{

    initHw();               // Initialize Hardware

    initComm();             // Initialize Communication Module

    initWTimer5();          //

    initRTC();              //

    initTestInterface();    //


    setDateTime(2019, 10, 19, 19, 10, 0);

    while(1)
    {
        testInterface();



    }

    //return 0;
}
