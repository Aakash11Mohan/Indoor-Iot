//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : headers.h                                                  //
// Date            : 04/08/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 2.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
// Hardware configuration:                                                      //
//                                                                              //
//                                                                              //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//                                                                              //
//******************************************************************************//


#ifndef __HEADERS_H
#define __HEADERS_H



//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//

#include <tm4c123gh6pm.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "rtctime.h"
#include "comms.h"



//*****************************************************************************//
//                                                                             //
//                 MACRO DEFINITIONS, DIRECTIVES and STRUCTURES                //
//                                                                             //
//*****************************************************************************//


//****************** Bit Banding defines for Pins *********************//      (for TM4C123GXL-TIVA-C LAUNCHPAD)

//Port F
#define PF1               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 1*4)))
#define PF2               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 2*4)))
#define PF3               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 3*4)))
#define PF4               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 4*4)))



//***************************** Board Modules Pins *************************// (for TM4C123GXL-TIVA-C LAUNCHPAD)

#define ONBOARD_RED_LED           PF1
#define ONBOARD_BLUE_LED          PF2
#define ONBOARD_GREEN_LED         PF3
#define ONBOARD_PUSH_BUTTON       PF4


#define MAX_DEVICES               10

//**************************** Structures ************************************//

// SyncMessage
typedef struct syncMessage
{
    uint8_t PREAMBLE[4];
    uint8_t SLOTNUM[2];
    uint8_t LENGTH[2];
    uint8_t NID[4];
    uint8_t NSLOT[2];
    uint8_t TSLOT[3];
    uint8_t BSLOT[2];
    uint8_t ASLOT[2];
    uint8_t TIME[6];
    uint8_t DATE[6];

}syncMessageType;

extern syncMessageType sync;


// Join response
typedef struct joinResponse
{
    uint8_t PREAMBLE[4];
    uint8_t SLOTNUM[2];
    uint8_t NID[4];
    uint8_t MAC[6];
    uint8_t DID[2];

}joinResponseType;

extern joinResponseType joinResp;


struct localTime
{
    char hours[2];
    char minutues[2];
    char sec[2];
    char pad;

}LTIME;


struct localDate
{
    char year[2];
    char month[2];
    char day[2];
    char pad;

}LDATE;


typedef struct deviceTable
{
    uint8_t DID;
    char    MAC[6];
    uint8_t NSLOT;

}deviceTableType;

extern deviceTableType devices[MAX_DEVICES];


//*****************************************************************************//
//                                                                             //
//                          EXTERN VARIABLES                                   //
//                                                                             //
//*****************************************************************************//

extern uint8_t  length;
extern uint16_t networkId;
extern uint8_t  numOfSlots;
extern uint16_t slotTime;
extern uint8_t  broadcastSlot;
extern uint8_t  accessSlot;

extern uint8_t joinRespButton;


//*****************************************************************************//
//                                                                             //
//                          Function Prototypes                                //
//                                                                             //
//*****************************************************************************//

//
//
//
void initHw();

//
//
//
void syncMessageSend(void);

//
//
//
void joinResponseMessageSend(void);

//
//
//
void joinResponseEnable(void);


//
//
//
void initTestInterface(void);

//
//
//
void testInterface(void);



#endif
