//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : comms.c                                                    //
// Date            : 03/22/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 1.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
// (not updated)                                                                //
// This Software was made under the guidance of Dr. Jason Losh,                 //
// The University of Texas at Arlington. Any UNAUTHORIZED use of this software, //
// without the prior permission and consent of Dr. Jason Losh or any of the,    //
// mentioned contributors is a direct violation of Copyright.                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//******************************************************************************//




//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//


#include "comms.h"
#include <stdlib.h>



//***************************** Global Scope **********************************//

// Receive Message Variables
uint16_t rNetworkID = 0;
uint8_t rSlotsReq = 0;

// Time Variables
uint8_t Hours   = 0;
uint8_t Minutes = 0;
uint8_t Seconds = 0;

// Date Variables
uint8_t Year    = 0;
uint8_t Month   = 0;
uint8_t Day     = 0;


// Flags
uint8_t joinReqFlag = 0;
uint8_t syncMesFlag = 0;
uint8_t responseFlag = 0;
uint8_t joinAckFlag = 0;


//
char rMacAddr[6] = {0};


//****************************** Local Scope ***********************************//  ?????

// loop variables
uint8_t i, j, k = 0;                 // receive index, used in uart isr

// buffers
char rArrayBuff[6] = {0};            // buffer for storing parsed data


// Flags
uint8_t timeOUT;
uint8_t timeoutUpdate;


// Message variables



// test variables
uint8_t AccessSlot = 0;
uint8_t minTime    = 0;

//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//



// Function for Initialing Communication module
// retval : none
// args   : none
void initComm(void)
{

    // xBee takes PC4 to DOUT pin (pin 2) and PC5 to DIN/CONFIG pin (pin 3), see XBee Pinout diagram

    //configure UART1 pins for PC4 and PC5
    SYSCTL_RCGCUART_R  |= SYSCTL_RCGCUART_R1;                                       // Turn-on UART1, leave other uarts in same status
    GPIO_PORTC_DEN_R   |= (1 << 4) | (1 << 5);                                      // Turn on Digital Operations on PC4 and PC5
    GPIO_PORTC_AFSEL_R |= (1 << 4) | (1 << 5);                                      // Select Alternate Functionality on PC4 and PC5
    GPIO_PORTC_PCTL_R  |= GPIO_PCTL_PC4_U1RX | GPIO_PCTL_PC5_U1TX;                  // Select UART1 Module and configure RX and TX

    //configure UART1 baud rate
    UART1_CTL_R   = 0;                                                              // turn-off UART0 to allow safe programming
    UART1_CC_R   |= UART_CC_CS_SYSCLK;                                              // use system clock (40 MHz)
    UART1_IBRD_R  = 21;                                                             // r = 40 MHz / (Nx115.2kHz), set floor(r)=21, where N=16
    UART1_FBRD_R  = 45;                                                             // round(fract(r)*64)=45
    UART1_LCRH_R |= UART_LCRH_WLEN_8 | UART_LCRH_FEN;                               // configure data length 8 bits, enable FIFO
    UART1_CTL_R  |= UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN;                  // enable TX, RX, and module
    UART1_IM_R = UART_IM_RXIM;                                                      // turn-on RX interrupt
    NVIC_EN0_R |= 1 << (INT_UART1-16);                                              // turn-on interrupt 22 (UART1)

}




void uart1ISR(void)
{

    uint8_t  len = 0;

    char c = UART1_DR_R & 0xFF;

    // Terminate when receive Null
    if(c == 0)
    {
        recvMessage.message[i] = 0;
        i = 0;

        // Checksum processing
        recvMessage.checksum = 0;
        len = strlen(recvMessage.message);

        // calculate checksum, don't add received checksum from message (len-1), last byte is checksum
        for(j=0; j < len - 1; j++)
            recvMessage.checksum = recvMessage.message[j] + ((recvMessage.checksum & 0xFF) + ((recvMessage.checksum >> 8) & 0xFF));


        // TODO Code for Receive FIFO will come here
        // put data from recvMessage to the FIFO,
        // Clear recvMessage structure,
        // pull data from FIFO and put it back to recv structure


        // check for checksum error and proceed only when success
        if(recvMessage.checksum == recvMessage.message[len-1])
        {

            // if response button is pressed
            if(responseFlag == 1)
            {

                // check for join request
                if(recvMessage.message[0] == 0xAA && recvMessage.message[1] == 0xAA && recvMessage.message[2] == 0xCC && recvMessage.message[3] == 0xCC)
                {
                    joinAckFlag = 1;

                    // Get Network ID
                    j = 0;
                    k = 0;
                    memset(rArrayBuff, NULL, 6);
                    for(j=4; j<=7; j++)
                    {
                        rArrayBuff[k++] = recvMessage.message[j];
                    }

                    rNetworkID = atoi(rArrayBuff);

                    // Get MAC address
                    j = 0;
                    k = 0;
                    memset(rMacAddr, NULL, 6);
                    for(j=8; j<=14; j++)
                    {
                        rMacAddr[k++] = recvMessage.message[j];
                    }

                    // parse slot request
                    j = 0;
                    k = 0;
                    memset(rArrayBuff, NULL, 6);
                    for(j=14; j<=15; j++)
                    {
                        rArrayBuff[k++] = recvMessage.message[j];
                    }

                    rSlotsReq = atoi(rArrayBuff);


                    // Calibrate Timer ISR to Broadcast slot

                    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;                     // Disable Timer
                    WTIMER5_TAMATCHR_R = (40000 * 300) -1;                // Load new value: slotTime = 100 and slot number = 3 for broadcast (3 * 100)
                    WTIMER5_TAV_R = 0;                                    // Make Timer 0
                    WTIMER5_CTL_R |= TIMER_CTL_TAEN;                      // Enable Timer


                    // Clear Buffer after receiving join request message
                    memset(&recvMessage, NULL, sizeof(recvMessage));


                }// join request check

            }// join response enable check

        }// Checksum

    }
    else
    {
        // store each byte to receive message buffer, global structure fined in comm.h, (check length of buffer)
        recvMessage.message[i++] = c;

    }

}


void receiveMessage(void)
{

    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;
    UART1_IM_R = UART_IM_RXIM;                       // turn-on RX interrupt
    NVIC_EN0_R |= 1 << (INT_UART1-16);               // turn-on interrupt 22 (UART1)


}




// Blocking Function for sending Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3)
// retval : none
// args   : Character Data (8-BIT) value
void sendData(const char data)
{
    while(UART1_FR_R & UART_FR_TXFF);
        UART1_DR_R = data;
}




// Blocking Function for sending Stream of Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3), with checksum
// retval : none
// args   : Data Stream / String value
void sendStream(char* data)
{
    uint8_t i        = 0;
    uint8_t len      = 0;
    uint8_t checksum = 0;

    len = strlen(data);                                                           // Calculate length of data string

    // Calculate Checksum
    for(i=0; i<len; i++)
        checksum = data[i] + ((checksum & 0xFF) + ((checksum >> 8) & 0xFF)) ;    // Avoid overflow from 8 bit, (Idea from RFC 1071.)

    data[i] = checksum;
    data[i+1] = 0;

    // Send Data
    for(i=0; i<len + 2; i++)
        sendData(data[i]);


}



// Function for Receiving data from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Character Data (8-Bit)
// args   : none
char recvData(void)
{
    while(UART1_FR_R & UART_FR_RXFE);
        return UART1_DR_R & 0xFF;;
}



// Function for Receiving data stream from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Signed Integer (8-Bit), 0: Success, -1: Fail, Checksum Error, -2: Timeout, no message received
// args   : String buffer to store data.
int8_t recvStream(char* buffer)
{
    char dataInput = 0;
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t len = 0;

    uint8_t checksum = 0;

    while(1)
    {
        dataInput = recvData();

       if(dataInput == 10)
           break;

       else
           buffer[i++] = dataInput;

       if(timeoutUpdate == 1)
           break;

    }

    len = strlen(buffer);

    // Check for Checksum Error
    for(j=0; j<len-1; j++)                                                                 // len - 1 for postion of checksum value
        checksum = buffer[j] + ((checksum & 0xFF) + ((checksum >> 8) & 0xFF)) ;            // Avoid overflow from 8 bit

    checksum = (char)checksum;

    if(checksum != buffer[len-1])                                                         // Generate Error with checksum
        return -1;

    if(timeoutUpdate == 1)
        return -2;

    return 0;
}



