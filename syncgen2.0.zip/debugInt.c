//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : debugInit.c                                                //
// Date            : 04/07/2019                                                 //
// Author          : Communications Team                                        //
// Copyright       : (c) 2019, Communications Team                              //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 1.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// CONTRIBUTORS : Kashish Shah, AaKash Mohan                                    //
// INTEGRATION  : Aditya Mall (04/07/2019)                                      //
//                                                                              //
// Any UNAUTHORIZED use of this software without the prior permission and,      //
// consent any of the mentioned contributors is a direct violation of,          //
// Copyright.                                                                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES BE LIABLE FOR,    //
// SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER.      //
//                                                                              //
//******************************************************************************//



//** LOG **//
//
//
// Date:
//
//
//
// Date: 04/07/2019
//    - Debug test interface and all implementations : Kashish Shah, Aakash Mohan
//    - Initial file Arrangement and Management      : Aditya Mall.
//
//** LOG **//




//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//


#include "headers.h"



//*****************************************************************************//
//                                                                             //
//                 MACRO DEFINITIONS, DIRECTIVES and STRUCTURES                //
//                                                                             //
//*****************************************************************************//


#ifndef LOCALECHO
//#define LOCALECHO
#endif

#ifndef DEBUG
//#define DEBUG
#endif


#define Max_Char 80


//*****************************************************************************//
//                                                                             //
//                          GLOBAL VARIABLES                                   //
//                                                                             //
//*****************************************************************************//


// TODO We don't need to declare variable here as it is externed in headers.h and gets modified in messageHandle.c
//syncMessageType sync;
//joinResponseType joinResp;


//Shell Variables
uint8_t count, j, argument1, argument2, argument3, a, alen,arg, args=0, pos[4], clen;
char ch, c, str[Max_Char+1], strv[10], statement [4][10], command[10], type[4], str2[5], string[10];
bool valid,comm = true;


// TODO remove below variables and call structure members at respective position
uint8_t Pre[4],SLOTNUM[2],LENGTH[2],NID[4],NSLOT[2],TSLOT[3],BSLOT[2],ASLOT[2],TIME[6],DATE[6];
uint8_t SLOTNUM_Resp[2],PREAMBLE_Resp[4],NID_Resp[4],DID_Resp[2],MAC_Resp[6];
char Preamble[4];





//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//


//
//
//
void initTestInterface(void)
{

    // Configure UART0 pins
    SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R0;                                        // turn-on UART0, leave other uarts in same status
    GPIO_PORTA_DEN_R |= 3;                                                          // default, added for clarity
    GPIO_PORTA_AFSEL_R |= 3;                                                        // default, added for clarity
    GPIO_PORTA_PCTL_R = GPIO_PCTL_PA1_U0TX | GPIO_PCTL_PA0_U0RX;


    // Configure UART0 baud rate
    UART0_CTL_R   = 0;                                                              // turn-off UART0 to allow safe programming
    UART0_CC_R   |= UART_CC_CS_SYSCLK;                                              // use system clock (40 MHz)
    UART0_IBRD_R  = 21;                                                             // r = 40 MHz / (Nx115.2kHz), set floor(r)=21, where N=16
    UART0_FBRD_R  = 45;                                                             // round(fract(r)*64)=45
    UART0_LCRH_R |= UART_LCRH_WLEN_8 | UART_LCRH_FEN;                               // configure data length 8 bits, enable FIFO
    UART0_CTL_R  |= UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN;                  // enable TX, RX, and module

}


//
//
//
void putcUart0(char c)
{
    while (UART0_FR_R & UART_FR_TXFF);
    UART0_DR_R = c;
}


// Blocking function that writes a string when the UART buffer is not full
//
//
void putsUart0(char* str)
{
    uint8_t i;
    for (i = 0; i < strlen(str); i++)
      putcUart0(str[i]);
}



// Blocking function that returns with serial data once the buffer is not empty
//
//
static char getcUart0()
{
    while (UART0_FR_R & UART_FR_RXFE);
        return UART0_DR_R & 0xFF;
}



// Function that checks whether the character is an Alphabet
//
//
static uint8_t isalpha(char c)
{
    uint8_t ch = (uint8_t) c;

    return (ch<=90&&ch>=65)||(ch<=122&&ch>=97);
}


// Function that checks whether the character is a Number
//
//
static uint8_t isnumber(char c)
{
    uint8_t ch = (uint8_t) c;
    return (ch<=57&&ch>=48);
}


// Function that checks whether the character is neither a Number nor an Alphabet
//
//
static uint8_t isdelim(char c)
{
    return (!isalpha(c) && !isnumber(c));
}


// Function that converts Upper-case Alphabets to Lower-case Alphabets
//
//
static char lower(char c)
{
    a = (uint8_t) c;

    return (char)a+32;
}


//
//
//
static char getsUart0()
{
    count=0;

    // TODO: MACRO Name in ALL CAPS
    while(count<Max_Char)
    {
        ch = getcUart0();


#ifdef LOCALECHO

        putcUart0(ch);

#endif

        j= (uint8_t) ch;

        if(j==8)
        {
            if(count!=0)
                count--;
            continue;
        }
        else
        {
            if(j==13)
            {
                break;
            }
            else
            {
                if(j<32)
                    continue;
                else
                {
                    if(isalpha(ch) && j<96)
                        str[count++]=lower(ch);
                    else
                        str[count++]=ch;
                }
            }
        }
    }

    str[count] = '\0';

    return(0);
}


// TODO remove extra commands / verbs from previous project
//Function to check whether the command is correct of wrong
//
//
static bool isCommand(char* verb, uint8_t arg)
{
    bool ret;
    if(strcmp(verb,"end") == 0)
        return true;
    if(arg==2)
    {
        if(strcmp(verb,"set") == 0 || strcmp(verb,"sched") == 0 || strcmp(verb,"rtos") == 0 || strcmp(verb,"kill") == 0)
            ret = true;
        else
        {
            putsUart0("\n\rWrong command\n\r");
            ret = false;
        }
    }
    else if(arg==0)
    {
        if(strcmp(verb,"sync") == 0  || strcmp(statement[0],"resp")==0 || strcmp(statement[0],"reboot")==0)
            ret = true;
        else
        {
            putsUart0("\n\rWrong command\n\r");
            ret = false;
        }
    }

    else
    {
        putsUart0("\n\rWrong number of arguments\n\r");
        ret = false;
    }
    return ret;
}



//
//
//
static uint8_t resetCount(void)
{
    uint8_t i,j;
    for(i=0;i<4;i++)
        for(j=0;j<10;j++)
            statement[i][j]='\0';
    return 0;
}



//
//
//
static uint8_t getstrUart0()
{
    putsUart0("\r\nEnter your input\r\n");
    getsUart0();

    resetCount();

#ifdef LOCALECHO
    for(a=0;a<strlen(str);a++)
    {
        putcUart0(str[a]);
    }
#endif

    putsUart0("\r\n");
    comm = true;
    args=0;
    clen = 0;
    a=0;
    alen = 0;
    while(a<strlen(str))
    {
        ch = str[a];
        if(isdelim(ch))
        {
            alen = 0;
            if(clen!=0)
                comm = false;

            a++;
            continue;

        }
        if(a==0 & !isdelim(ch))
        {
            pos[args] = a;
            if(isalpha(ch))
            {
                command[clen++] = ch;
                type[args] = 'a';
            }
            else
                type[args] = 'n';

            args++;
            //putcUart0(ch);
        }
        else if(!isdelim(ch))
        {
            if(comm)
            {
                command[clen] = ch;
                clen++;
            }

            if(isdelim(str[a-1]))
            {
                putsUart0("\r\n");
                pos[args] = a;
                if(isalpha(ch))
                    type[args] = 'a';
                else
                    type[args] = 'n';
                args++;
            }
            if(!comm)
            {
                statement[args-1][alen++] = ch;
            }

            //putcUart0(ch);
        }
        a++;
    }

    command[clen] = '\0';

    for(a=0;a<clen;a++)
        statement[0][a]=command[a];

#ifdef DEBUG
    putsUart0("\r\n\r\nThe command is: ");
    putsUart0(command);
#endif

    if(isCommand(command,args-1))
    {
        valid = true;
#ifdef DEBUG
        putsUart0("\r\nIt is a valid command\r\n");
#endif
    }
    else
    {
        valid = false;
#ifdef DEBUG
        putsUart0("\r\nIt is not a valid command\r\n");
#endif
    }


#ifdef DEBUG
    putsUart0("\r\n\r\nNumber of Args =");
    ltoa(args,string);
    putsUart0(string);
#endif


#ifdef DEBUG
    for(a = 0;a<args;a++)
    {
        putsUart0("\r\npos[");
        ltoa(a,string);
        putsUart0(string);
        putsUart0("] = ");
        ltoa(pos[a],string);
        putsUart0(string);
        putsUart0("\r\ntype[");
        ltoa(a,string);
        putsUart0(string);
        putsUart0("] = ");
        putcUart0(type[a]);
    }
#endif

    return 0;
}


//
//
//
void testInterface(void)
{
    getstrUart0();

    if(valid)
    {
        // TODO clean up the below test code
        if(strcmp(statement[0],"set")==0)
        {
            if(strcmp(statement[1],"red")==0)
            {
                if(strcmp(statement[2],"on")==0)
                    ONBOARD_RED_LED = 1;
                else if(strcmp(statement[2],"off")==0)
                    ONBOARD_RED_LED = 1;
            }
        }
        // TODO we will tell everyone to put integers as MAC address, let's discuss this
        else if(strcmp(statement[0],"sync")==0)
        {
            uint8_t x;
            putsUart0("\r\nPREAMBLE = ");
            //                putsUart0("] = ");
            //                putsUart0(string);

            //                    ltoa(Pre[0],string);
            //                    putcUart0(Preamble[0]);

            putsUart0("\r\nSLOTNUM = ");
            for(x=0;x<2;x++)
            {
                ltoa(sync.SLOTNUM[x]-48,string);
                putsUart0(string);
            }

            putsUart0("\r\nLENGTH = ");
            for(x=0;x<2;x++)
            {
                ltoa(LENGTH[x]-48,string);

                putsUart0(string);

            }

            putsUart0("\r\nNID = ");
            for(x=0;x<4;x++)
            {
                ltoa(NID[x]-48,string);

                putsUart0(string);

            }
            putsUart0("\r\nNSLOT = ");
            for(x=0;x<2;x++)
            {
                ltoa(NSLOT[x]-48,string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
            putsUart0("\r\nTSLOT = ");
            for(x=0;x<3;x++)
            {
                ltoa(TSLOT[x]-48,string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
            putsUart0("\r\nBSLOT = ");
            for(x=0;x<2;x++)
            {
                ltoa(BSLOT[x]-48,string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
            putsUart0("\r\nASLOT = ");
            for(x=0;x<2;x++)
            {
                ltoa(ASLOT[x]-48,string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
            putsUart0("\r\nTIME = ");
            for(x=0;x<6;x++)
            {
                ltoa(TIME[x]-48,string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
            putsUart0("\r\nDATE = ");
            for(x=0;x<6;x++)
            {
                ltoa(DATE[x]-48,string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
        }

        // TODO we don't need to print join response, print flags instead, there are flags in comms.h you can easily print them here
        //
        else if (strcmp(statement[0],"resp")==0)
        {
            uint8_t x;
            putsUart0("\r\nPREAMBLE = ");
            for(x=0;x<4;x++)
            {
                ltoa(NID[x]-48,string);

                //                putsUart0("] = ");

                putsUart0(string);

            }

            putsUart0("\r\n");
            putcUart0(responseFlag + 48);

            putsUart0("\r\nSLOTNUM = ");
            for(x=0;x<2;x++)
            {
                ltoa(SLOTNUM_Resp[x]-48,string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
            putsUart0("\r\nNID = ");
            for(x=0;x<4;x++)
            {
                ltoa(NID_Resp[x],string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
            putsUart0("\r\nDID = ");
            for(x=0;x<2;x++)
            {
                ltoa(DID_Resp[x],string);

                //                putsUart0("] = ");

                putsUart0(string);

            }
            putsUart0("\r\nMAC = ");
            for(x=0;x<6;x++)
            {
                ltoa(MAC_Resp[x],string);

                //                putsUart0("] = ");

                putsUart0(string);

            }

        }
    }
    //
}





