//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : messageHandle.c                                            //
// Date            : 04/08/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 2.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
// Hardware configuration:                                                      //
//                                                                              //
//                                                                              //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// CONTRIBUTORS: Aditya Mall, Murilo Pinheiro                                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//                                                                              //
//******************************************************************************//






//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//



#include "headers.h"




//*****************************************************************************//
//                                                                             //
//                          GLOBAL VARIABLES                                   //
//                                                                             //
//*****************************************************************************//


// Structure variables
syncMessageType  sync;
joinResponseType joinResp;
deviceTableType  devices[MAX_DEVICES];

// local buffer for storing values and sending to UART1
char syncMessageBuffer[sizeof(syncMessageType) + 2];         // For sending sync message
char responseMessageBuffer[sizeof(joinResponseType) + 2];    // For sending join response message


// Sync Generator / Server Variables
uint8_t  slotNumber = 1;                      // Slot Number of server/ sync generator                        fixed

// Sync Message Body Variables
uint8_t  length        = 0;                   // Length of message body                                       variable?
uint16_t networkId     = 8118;                // Network ID, predefined and unique for every system,          fixed
uint8_t  numOfSlots    = 3;                   // Total Number of Slots, Gets from the EEPROM                  variable
uint16_t slotTime      = 100;                 // Time of each slot?,                                          fixed
uint8_t  broadcastSlot = 3;                   // Slot Number of Broadcast slot,                               fixed
uint8_t  accessSlot    = 2;                   // Slot Number of Access Slot,                                  fixed


// Buffers
char numBuff[6] = {0};


// Peripheral Variables
uint8_t joinRespButton = 0;

//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//





void syncMessageSend(void)
{

    // Preamble
    sync.PREAMBLE[0] = 0xAA;
    sync.PREAMBLE[1] = 0xAA;
    sync.PREAMBLE[2] = 0x55;
    sync.PREAMBLE[3] = 0x55;


    // Slot Number
    memset(numBuff, NULL, sizeof(numBuff));
    if(slotNumber < 10)
    {
        numBuff[0] = '0';
        numBuff[1] = slotNumber + 48;
    }
    else
    {
        ltoa(slotNumber, numBuff);
    }
    memcpy(sync.SLOTNUM,numBuff,sizeof(numBuff));


    // Length
    memset(numBuff, NULL, sizeof(numBuff));
    length = sizeof(syncMessageBuffer);
    ltoa(length, numBuff);
    memcpy(sync.LENGTH,numBuff,sizeof(numBuff));



    // NID
    memset(numBuff, NULL, sizeof(numBuff));
    ltoa(networkId ,numBuff);
    memcpy(sync.NID,numBuff,sizeof(numBuff));



    // NUM OF SLOT
    memset(numBuff, NULL, sizeof(numBuff));
    if(numOfSlots < 10)
    {
        numBuff[0] = '0';
        numBuff[1] = numOfSlots + 48;
    }
    else
    {
        ltoa(numOfSlots, numBuff);
    }
    memcpy(sync.NSLOT,numBuff,sizeof(numBuff));


    // Time of Slot
    memset(numBuff, NULL, sizeof(numBuff));
    ltoa(slotTime, numBuff);
    memcpy(sync.TSLOT, numBuff, sizeof(numBuff));


    // Broadcast Slot
    memset(numBuff, NULL, sizeof(numBuff));
    if(broadcastSlot < 10)
    {
        numBuff[0] = '0';
        numBuff[1] = broadcastSlot + 48;
    }
    else
    {
        ltoa(broadcastSlot, numBuff);
    }
    memcpy(sync.BSLOT,numBuff,sizeof(numBuff));


    // Access Slot
    memset(numBuff, NULL, sizeof(numBuff));
    if(accessSlot < 10)
    {
        numBuff[0] = '0';
        numBuff[1] = accessSlot + 48;
    }
    else
    {
        ltoa(accessSlot, numBuff);
    }
    memcpy(sync.ASLOT,numBuff,sizeof(numBuff));


    //***********************TIME**********************//
    getDateTime();

    memset(&LTIME, NULL, sizeof(LTIME));

    if(time.hours < 10)
    {
        LTIME.hours[0] = 48;
        LTIME.hours[1] = time.hours + 48;
    }
    else
        ltoa(time.hours, LTIME.hours);

    if(time.minutes < 10)
    {
        LTIME.minutues[0] = 48;
        LTIME.minutues[1] = time.minutes + 48;
    }
    else
        ltoa(time.minutes, LTIME.minutues);

    if(time.seconds < 10)
    {
        LTIME.sec[0] = 48;
        LTIME.sec[1] = time.seconds + 48;
    }
    else
        ltoa(time.seconds, LTIME.sec);

    memcpy(sync.TIME, &LTIME, sizeof(LTIME));


    //*************************DATE*********************//

    memset(&LDATE, NULL, sizeof(LDATE));

    if(date.year < 10)
    {
        LDATE.year[0] = 48;
        LDATE.year[1] = date.year + 48;
    }
    else
        ltoa(date.year, LDATE.year);

    if(date.month < 10)
    {
        LDATE.month[0] = 48;
        LDATE.month[1] = date.month  + 48;
    }
    else
        ltoa(date.month, LDATE.month);

    if(date.day < 10)
    {
        LDATE.day[0] = 48;
        LDATE.day[1] = date.day + 48;
    }
    else
        ltoa(date.day, LDATE.day);


    memcpy(sync.DATE, &LDATE, sizeof(LDATE));



    // Store all details to buffer and send message (check size of this global buffer before sending)
    memset(syncMessageBuffer, NULL, sizeof(syncMessageBuffer));
    memcpy(syncMessageBuffer, &sync, sizeof(sync));
    sendStream(syncMessageBuffer);

    //TODO add code for clearing this buffer after sending

}


void joinResponseMessageSend(void)
{

    uint8_t i, j = 0;
    uint8_t Found = 0;

    // Send message only when you get the correct network ID
    if(rNetworkID == networkId)
    {

        // Preamble
        joinResp.PREAMBLE[0] = 0xAA;
        joinResp.PREAMBLE[1] = 0xAA;
        joinResp.PREAMBLE[2] = 0xBB;
        joinResp.PREAMBLE[3] = 0xBB;


        // Slot Number
        memset(numBuff, NULL, sizeof(numBuff));
        if(slotNumber < 10)
        {
            numBuff[0] = '0';
            numBuff[1] = slotNumber + 48;
        }
        else
        {
            ltoa(slotNumber, numBuff);
        }
        memcpy(joinResp.SLOTNUM,numBuff,sizeof(numBuff));


        // NID of Network
        memset(numBuff, NULL, 6);
        ltoa(networkId, numBuff);
        memcpy(joinResp.NID, numBuff, sizeof(numBuff));


        // MAC Address
        for(i=0; i<6; i++)
        {
            joinResp.MAC[j++] = rMacAddr[i];
        }



        //********* Assign slot to join ***************//

        // Check if device is already in the table if not then assign a slot
        for(i=0; i<10; i++)
        {
            if(memcmp(devices[i].MAC, rMacAddr, 6) == 0)
            {
                Found = 1;
                break;
            }
            else if(memcmp(devices[i].MAC, NULL, 1) == 0)
            {

                // TODO Better way of doing it ?
                numOfSlots++;

                devices[i].DID = numOfSlots;
                devices[i].NSLOT = rSlotsReq;

                // if request slots by current device is greater than 1,
                // then increase the total number of slots
                if(rSlotsReq > 1)
                    numOfSlots = (numOfSlots + rSlotsReq) - 1;

                memcpy(devices[i].MAC, rMacAddr,6);

                break;
            }

        }

        // Assign slot
        if(Found == 0)
        {
            memset(numBuff, NULL, sizeof(numBuff));
            if(devices[i].DID < 10)
            {
                numBuff[0] = '0';
                numBuff[1] = devices[i].DID + 48;
            }
            else
            {
                ltoa(devices[i].DID, numBuff);
            }

            memcpy(joinResp.DID,numBuff,sizeof(numBuff));
        }

        // if already exists in table
        if(Found == 1)
        {
            memset(numBuff, NULL, sizeof(numBuff));
            if(devices[i].DID < 10)
            {
                numBuff[0] = '0';
                numBuff[1] = devices[i].DID + 48;
            }
            else
            {
                ltoa(devices[i].DID, numBuff);
            }
            memcpy(joinResp.DID,numBuff,sizeof(numBuff));
        }

        responseFlag   = 0;
        joinRespButton = 0;

        // Store all details to buffer and send message (check size of this global buffer before sending)
        memset(responseMessageBuffer, NULL, sizeof(responseMessageBuffer));
        memcpy(responseMessageBuffer, &joinResp, sizeof(joinResp));
        sendStream(responseMessageBuffer);

        //TODO add code for clearing this buffer after sending, put debug point here to see the buffer then

    }// Network ID check if condition
    else
    {
        //assert error
    }

    // clear this flag, even if wrong network ID is received and message is not sent
    joinAckFlag = 0;

}// End of function


//LEGACY: Blocking function
void joinResponseEnable(void)
{

    while(ONBOARD_PUSH_BUTTON);
    joinRespButton = 1;
    responseFlag = 1;

}




