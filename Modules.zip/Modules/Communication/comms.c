//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : comms.c                                                    //
// Date            : 03/25/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 1.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// This Software was made under the guidance of Dr. Jason Losh,                 //
// The University of Texas at Arlington. Any UNAUTHORIZED use of this software, //
// without the prior permission and consent of Dr. Jason Losh or any of the,    //
// mentioned contributors is a direct violation of Copyright.                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//******************************************************************************//




//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//


#include "comms.h"


uint8_t timeOUT;

uint8_t timeoutUpdate;

//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//



// Function for Initialing Communication module
// retval : none
// args   : none
void initComm(void)
{

    // xBee takes PC4 to DOUT pin (pin 2) and PC5 to DIN/CONFIG pin (pin 3), see XBee Pinout diagram

    //configure UART1 pins for PC4 and PC5
    SYSCTL_RCGCUART_R  |= SYSCTL_RCGCUART_R1;                                       // Turn-on UART1, leave other uarts in same status
    GPIO_PORTC_DEN_R   |= (1 << 4) | (1 << 5);                                      // Turn on Digital Operations on PC4 and PC5
    GPIO_PORTC_AFSEL_R |= (1 << 4) | (1 << 5);                                      // Select Alternate Functionality on PC4 and PC5
    GPIO_PORTC_PCTL_R  |= GPIO_PCTL_PC4_U1RX | GPIO_PCTL_PC5_U1TX;                  // Select UART1 Module and configure RX and TX

    //configure UART1 baud rate
    UART1_CTL_R   = 0;                                                              // turn-off UART0 to allow safe programming
    UART1_CC_R   |= UART_CC_CS_SYSCLK;                                              // use system clock (40 MHz)
    UART1_IBRD_R  = 21;                                                             // r = 40 MHz / (Nx115.2kHz), set floor(r)=21, where N=16
    UART1_FBRD_R  = 45;                                                             // round(fract(r)*64)=45
    UART1_LCRH_R |= UART_LCRH_WLEN_8 | UART_LCRH_FEN;                               // configure data length 8 bits, enable FIFO
    UART1_CTL_R  |= UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN;                  // enable TX, RX, and module

    // Configure Timer 1 for timeout service
    SYSCTL_RCGCTIMER_R |= SYSCTL_RCGCTIMER_R1;                                      // turn-on timer
    TIMER1_CTL_R &= ~TIMER_CTL_TAEN;                                                // turn-off timer before reconfiguring
    TIMER1_CFG_R = TIMER_CFG_32_BIT_TIMER;                                          // configure as 32-bit timer (A+B)
    TIMER1_TAMR_R = TIMER_TAMR_TAMR_1_SHOT | TIMER_TAMR_TACMR;                      // configure for periodic mode (count down)
    TIMER1_TAILR_R = 40000000 * 4;                                                  // set load value to 2e5 for 200 Hz interrupt rate
    TIMER1_IMR_R = TIMER_IMR_TATOIM;                                                // turn-on interrupts

}


void timer1AISR(void)
{
    timeOUT = 1;

    TIMER1_ICR_R = TIMER_ICR_TATOCINT;
    TIMER1_CTL_R &= ~TIMER_CTL_TAEN;
}



// Blocking Function for sending Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3)
// retval : none
// args   : Character Data (8-BIT) value
void sendData(const char data)
{
    while(UART1_FR_R & UART_FR_TXFF);
        UART1_DR_R = data;
}




// Blocking Function for sending Stream of Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3), with checksum
// retval : none
// args   : Data Stream / String value
void sendStream(const char* data)
{
    uint8_t i        = 0;
    uint8_t len      = 0;
    uint8_t checksum = 0;

    len = strlen(data);                                                           // Calculate length of data string

    // Calculate Checksum
    for(i=0; i<len; i++)
        checksum = data[i] + ((checksum & 0xFF) + ((checksum >> 8) & 0xFF)) ;    // Avoid overflow from 8 bit, (Idea from RFC 1071.)

    // Send Data
    for(i=0; i<len; i++)
        sendData(data[i]);

    // Send checksum
    sendData((char)checksum);
    sendData('\n');

}



// Function for Receiving data from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Character Data (8-Bit)
// args   : none
char recvData(void)
{
    NVIC_EN0_R |= 1 << (INT_TIMER1A-16);
    TIMER1_CTL_R |= TIMER_CTL_TAEN;

    while((UART1_FR_R & UART_FR_RXFE) && !timeOUT);

    if(timeOUT == 1)
    {
        timeoutUpdate = 1;
        timeOUT = 0;
        NVIC_DIS0_R |= 1 << (INT_TIMER1A-16);
    }
    else
    {
        timeOUT = 0;
        timeoutUpdate = 0;
        TIMER1_TAILR_R = 40000000 * 4;
        TIMER1_CTL_R &= ~TIMER_CTL_TAEN;
        return UART1_DR_R & 0xFF;
    }

    return 0;
}



// Function for Receiving data stream from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Signed Integer (8-Bit), 0: Success, -1: Fail, Checksum Error, -2: Timeout, no message received
// args   : String buffer to store data.
int8_t recvStream(char* buffer)
{
    char dataInput = 0;
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t len = 0;

    uint8_t checksum = 0;

    while(1)
    {
        dataInput = recvData();

       if(dataInput == 10)
           break;

       else
           buffer[i++] = dataInput;

       if(timeoutUpdate == 1)
           break;

    }

    len = strlen(buffer);

    // Check for Checksum Error
    for(j=0; j<len-1; j++)                                                                 // len - 1 for postion of checksum value
        checksum = buffer[j] + ((checksum & 0xFF) + ((checksum >> 8) & 0xFF)) ;            // Avoid overflow from 8 bit

    checksum = (char)checksum;

    if(checksum != buffer[len-1])                                                         // Generate Error with checksum
        return -1;

    if(timeoutUpdate == 1)
        return -2;

    return 0;
}



