//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : rtctime.c                                                  //
// Date            : 03/25/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         :                                                            //
// Version Control : GIT                                                        //
//                                                                              //
// Hardware configuration:                                                      //
//                                                                              //
//                                                                              //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//                                                                              //
//******************************************************************************//




//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//


#include "rtctime.h"



//*****************************************************************************//
//                                                                             //
//                          Function Prototypes                                //
//                                                                             //
//*****************************************************************************//



// Function for Initializing Real-Time Clock
// retval : Time in seconds
// args   : 6 arguments, value of year, month, day, hours, minutes, seconds
void initRTC(void)
{
    SYSCTL_RCGCHIB_R |= SYSCTL_RCGCHIB_R0;     // Hibernation Module clock enable

    HIB_CTL_R &= ~(HIB_CTL_RTCEN);             // Clear the bit before setting it up

    while((HIB_CTL_R & HIB_CTL_WRC) == 0);     // Wait for WRC (Write Complete bit) to clear, clear: Interface ready to accept a write
    HIB_CTL_R |= HIB_CTL_CLK32EN;              // Enable Hibernation module clock source as 32.768 Khz Clock (Real-Time Clock)

    while((HIB_CTL_R & HIB_CTL_WRC) == 0);     // Wait for WRC (Write Complete bit) to clear, clear: Interface ready to accept a write
    HIB_CTL_R |= HIB_CTL_RTCEN;                // Enable Real-Time Clock Counter

}



// Function for setting Time and Date
// retval : Time in seconds
// args   : 6 arguments, value of year, month, day, hours, minutes, seconds
uint32_t setDateTime(uint16_t year, uint8_t month, uint8_t days, uint8_t hours, uint8_t minutes, uint8_t seconds)
{
    uint32_t time = 0;                                                        // Initialize Time Variable
    uint8_t reducedYear = 0;;

    reducedYear = year % 2000;

//    //*********** This enclosed section sometimes produces errors****************//
//    // check for seconds
//    while(seconds >= 60)
//    {
//        minutes++;
//        seconds = seconds - 60;
//    }
//
//    // check for minutes
//    while(minutes >= 60)
//    {
//        hours++;
//        minutes = minutes - 60;
//    }
//
//    // check for hours
//    while(hours >= 24)
//    {
//        days++;
//        hours = hours - 24;
//    }
//    //*********** This enclosed section sometimes produces errors****************//

    time = (days * 24 * 3600) + hours * 3600 + minutes * 60 + seconds;        // Seconds Calculation

    date.month = month;                                                       // Store Value of Month
    date.year  = reducedYear;                                                 // Store Value of Year

    while((HIB_CTL_R & HIB_CTL_WRC) == 0);                                    // Wait for WRC (Write Complete bit) to clear, clear: Interface ready to accept a write
    HIB_RTCLD_R = time;                                                       // Load the value  of time variable to RTC load register

    return time;
}



// Function for reading time
// retval : Value of "time" Data Strcuture declared in header file
// args   : none
struct rtcTime getDateTime(void)
{

    date.dHead = 'd';

    date.day = ( (HIB_RTCC_R / 3600) / 24);

    // Months with 31 Days
    if(date.month == 1 || date.month == 3 || date.month == 5 || date.month == 7 || date.month == 8 || date.month == 10 || date.month == 12)
    {
        if(date.day > 31)
        {
            date.month++;
            date.day = 0;
            setDateTime(date.year, date.month, 1, 0, 0, 0);                                // Start with day 1
        }
    }

    // Months with 30 days
    if(date.month == 4 || date.month == 6 || date.month == 9 || date.month == 11)
    {
        if(date.day > 30)
        {
            date.month++;
            date.day = 0;
            setDateTime(date.year, date.month, 1, 0, 0, 0);
        }
    }

    // Leap year Calculation
    if(date.month == 2)
    {
        if( (date.year % 400 == 0 || date.year % 100 != 0) && (date.year % 4 == 0) )
        {
            if(date.day > 29)
            {
                date.month++;
                date.day = 0;
                setDateTime(date.year, date.month, 1, 0, 0, 0);
            }
        }
        else
        {
            if(date.day > 28)
            {
                date.month++;
                date.day = 0;
                setDateTime(date.year, date.month, 1, 0, 0, 0);
            }
        }
    }

    if(date.month > 12)
    {
        date.year++;
        date.month = 0;
        setDateTime(date.year, 1, 1, 0, 0, 0);
    }


    time.tHead = 't';

    time.hours = (HIB_RTCC_R / 3600) % 24;

    time.minutes = (HIB_RTCC_R % 3600) / 60 ;

    time.seconds = (HIB_RTCC_R % 3600) % 60;

    return time;
}




