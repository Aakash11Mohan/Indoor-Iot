//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : dev1.c                                                 //
// Author          : Aditya Mall                                                //
// Date            : 03/17/2019                                                 //
// Copyright       : (c) 2019, Aditya Mall, Mentor: Dr. Jason Losh,             //
//                   The University of Texas at Arlington.                      //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         :                                                            //
// Version Control : GIT                                                        //
//                                                                              //
// Hardware configuration:                                                      //
//                                                                              //
//                                                                              //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// This Software was made by Aditya Mall, under the guidance of Dr. Jason Losh, //
// The University of Texas at Arlington. Any UNAUTHORIZED use of this software, //
// without the prior permission and consent of Dr. Jason Losh or any of the,    //
// mentioned contributors is a direct violation of Copyright.                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
// For more info please contact: aditya.mall@mavs.uta.edu                       //
//                                                                              //
//******************************************************************************//



//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//

#include <tm4c123gh6pm.h>
#include <string.h>
#include <stdint.h>
#include "comms.h"


//*****************************************************************************//
//                                                                             //
//                 MACRO DEFINITIONS, DIRECTIVES and STRUCTURES                //
//                                                                             //
//*****************************************************************************//


//****************** Bit Banding defines for Pins *********************//      (for TM4C123GXL-TIVA-C LAUNCHPAD)

//Port F
#define PF1               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 1*4)))
#define PF2               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 2*4)))
#define PF3               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 3*4)))
#define PF4               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 4*4)))



//***************************** Board Modules Pins *************************// (for TM4C123GXL-TIVA-C LAUNCHPAD)

#define ONBOARD_RED_LED           PF1
#define ONBOARD_BLUE_LED          PF2
#define ONBOARD_GREEN_LED         PF3
#define ONBOARD_PUSH_BUTTON       PF4


//*****************************************************************************//
//                                                                             //
//                          Function Prototypes                                //
//                                                                             //
//*****************************************************************************//

void initHw();
void clearBuffer(char *globalRecvBuff);



//*****************************************************************************//
//                                                                             //
//                          GLOBAL VARIABLES                                   //
//                                                                             //
//*****************************************************************************//

char recvBuffer[25] = {0};     // Buffer for storing  receive data, 23 + 2 bits for checksum and new line char


//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//

void initHw()
{
    //******************************************************* Clock Configs ******************************************************************//

    // Configure System clock as 40Mhz
    SYSCTL_RCC_R = SYSCTL_RCC_XTAL_16MHZ | SYSCTL_RCC_OSCSRC_MAIN | SYSCTL_RCC_USESYSDIV | (0x04 << SYSCTL_RCC_SYSDIV_S);

    // Enable GPIO port A, and F peripherals
    SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOA | SYSCTL_RCGC2_GPIOF | SYSCTL_RCGC2_GPIOC;



    //**************************************************** On Board Modules ******************************************************************//

    // Configure On boards RED, GREEN and BLUE led and Pushbutton Pins
    GPIO_PORTF_DEN_R |= (1 << 1) | (1 << 2) | (1 << 3) | (1 << 4);                  // Enable Digital
    GPIO_PORTF_DIR_R |= (1 << 1) | (1 << 2) | (1 << 3);                             // Enable as Output
    GPIO_PORTF_DIR_R &= ~(0x10);                                                    // Enable push button as Input
    GPIO_PORTF_PUR_R |= 0x10;                                                       // Enable internal pull-up for push button

}


// Function for clearing global receive data buffer, optional
void clearBuffer(char *globalRecvBuff)
{

    uint8_t i = 0;

    uint8_t len = 0;

    len = strlen(globalRecvBuff);

    for(i=0; i < len; i++)
    {
        globalRecvBuff[i] = 0;

    }

}


// Main receiver message, every toggle means two message receive sequence
int main(void)
{
    int8_t retval = 0; // For return value  of checksum error

    initHw();          // Initialize Hardware

    initComm();        // Initialize Comms Module

    while(1)
    {
        memset(recvBuffer, NULL, sizeof(recvBuffer));         // Clear Buffer, before storing data, (best practice)

        retval = recvStream(recvBuffer);                      // Receive data stream to global buffer
        if(retval == -1)                                      // If checksum error
        {
            ONBOARD_RED_LED = 1;                              // Set led red to show checksum error
            memset(recvBuffer, NULL, sizeof(recvBuffer));     // clear buffer and try again
        }
        else if(retval == -2)                                 // -2 for timeout
        {
            ONBOARD_GREEN_LED ^= 1;
            ONBOARD_BLUE_LED = 0;
            ONBOARD_RED_LED = 0;

        }
        else
        {
            ONBOARD_BLUE_LED ^= 1;                            // Toggle BLUE Led when message is received, without error
            ONBOARD_RED_LED = 0;                              // Clear Red led if previous transfer had checksum error
            ONBOARD_GREEN_LED = 0;
            memset(recvBuffer, NULL, sizeof(recvBuffer));     // Clear Buffer
        }




    }

    //return 0;
}
