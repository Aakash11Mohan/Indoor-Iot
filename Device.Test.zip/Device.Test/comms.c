//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : comms.c                                                    //
// Date            : 03/22/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 1.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// This Software was made under the guidance of Dr. Jason Losh,                 //
// The University of Texas at Arlington. Any UNAUTHORIZED use of this software, //
// without the prior permission and consent of Dr. Jason Losh or any of the,    //
// mentioned contributors is a direct violation of Copyright.                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//******************************************************************************//




//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//


#include "comms.h"
#include <stdlib.h>


// Receive Message Variables
uint16_t networkID = 0;

// Time Variables
uint8_t Hours   = 0;
uint8_t Minutes = 0;
uint8_t Seconds = 0;

// Date Variables
uint8_t Year    = 0;
uint8_t Month   = 0;
uint8_t Day     = 0;


// Flags
uint8_t timeOUT;
uint8_t timeoutUpdate;
uint8_t joinReqFlag = 0;
uint8_t syncMesFlag = 0;

// loop variables
uint8_t i, j, k = 0;                 // receive index, used in uart isr



// buffers
char rArrayBuff[6] = {0};     // buffer for storing parsed data



// test variables

uint8_t AccessSlot = 0;
uint8_t minTime    = 0;

uint8_t AslotRecvd = 0;

//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//



// Function for Initialing Communication module
// retval : none
// args   : none
void initComm(void)
{

    // xBee takes PC4 to DOUT pin (pin 2) and PC5 to DIN/CONFIG pin (pin 3), see XBee Pinout diagram

    //configure UART1 pins for PC4 and PC5
    SYSCTL_RCGCUART_R  |= SYSCTL_RCGCUART_R1;                                       // Turn-on UART1, leave other uarts in same status
    GPIO_PORTC_DEN_R   |= (1 << 4) | (1 << 5);                                      // Turn on Digital Operations on PC4 and PC5
    GPIO_PORTC_AFSEL_R |= (1 << 4) | (1 << 5);                                      // Select Alternate Functionality on PC4 and PC5
    GPIO_PORTC_PCTL_R  |= GPIO_PCTL_PC4_U1RX | GPIO_PCTL_PC5_U1TX;                  // Select UART1 Module and configure RX and TX

    //configure UART1 baud rate
    UART1_CTL_R   = 0;                                                              // turn-off UART0 to allow safe programming
    UART1_CC_R   |= UART_CC_CS_SYSCLK;                                              // use system clock (40 MHz)
    UART1_IBRD_R  = 21;                                                             // r = 40 MHz / (Nx115.2kHz), set floor(r)=21, where N=16
    UART1_FBRD_R  = 45;                                                             // round(fract(r)*64)=45
    UART1_LCRH_R |= UART_LCRH_WLEN_8 | UART_LCRH_FEN;                               // configure data length 8 bits, enable FIFO
    UART1_CTL_R  |= UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN;                  // enable TX, RX, and module
    UART1_IM_R = UART_IM_RXIM;                                                      // turn-on RX interrupt
    NVIC_EN0_R |= 1 << (INT_UART1-16);                                              // turn-on interrupt 22 (UART1)

}



static void getAccessSlot(void)
{

    // parse access slot number
    j = 0;
    k = 0;
    memset(rArrayBuff, NULL, 6);
    for(j=19; j<=20; j++)
    {
        rArrayBuff[k++] = recvMessage.message[j];
    }

    // store access slot number
    recvMessage.rSlotNum = atoi(rArrayBuff);


    // Calibrate Timer ISR to
    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;
    WTIMER5_TAMATCHR_R = (40000 - 1) * recvMessage.rSlotTime * recvMessage.rSlotNum;
    WTIMER5_CTL_R |= TIMER_CTL_TAEN;


    AslotRecvd = 1;

}



void uart1ISR(void)
{

    //uint8_t j, k = 0;
    uint8_t  len = 0;

    char c = UART1_DR_R & 0xFF;

    // Terminate when receive Null
    if(c == 0)
    {
        recvMessage.message[i] = 0;
        i = 0;

        // Checksum processing
        recvMessage.checksum = 0;
        len = strlen(recvMessage.message);

        // calculate checksum, don't add received checksum from server (len-1)
        for(j=0; j < len - 1; j++)
            recvMessage.checksum = recvMessage.message[j] + ((recvMessage.checksum & 0xFF) + ((recvMessage.checksum >> 8) & 0xFF));


        // check for checksum error and proceed only when success
        if(recvMessage.checksum == recvMessage.message[len-1])
        {
            // check for sync message
            if(recvMessage.message[0] == 0xAA && recvMessage.message[2] == 0x55)
            {
                syncMesFlag = 1;

                // Parse time for RTC
                memset(rArrayBuff, NULL, 6);
                rArrayBuff[0] = recvMessage.message[21];
                rArrayBuff[1] = recvMessage.message[22];

                Hours = atoi(rArrayBuff);


                memset(rArrayBuff, NULL, 6);
                rArrayBuff[0] = recvMessage.message[23];
                rArrayBuff[1] = recvMessage.message[24];

                Minutes = atoi(rArrayBuff);


                memset(rArrayBuff, NULL, 6);
                rArrayBuff[0] = recvMessage.message[25];
                rArrayBuff[1] = recvMessage.message[26];

                Seconds = atoi(rArrayBuff);


                // Parse Date for RTC
                memset(rArrayBuff, NULL, 6);
                rArrayBuff[0] = recvMessage.message[27];
                rArrayBuff[1] = recvMessage.message[28];

                Year = atoi(rArrayBuff);


                memset(rArrayBuff, NULL, 6);
                rArrayBuff[0] = recvMessage.message[29];
                rArrayBuff[1] = recvMessage.message[30];

                Month = atoi(rArrayBuff);


                memset(rArrayBuff, NULL, 6);
                rArrayBuff[0] = recvMessage.message[31];
                rArrayBuff[1] = recvMessage.message[32];

                Day = atoi(rArrayBuff);

                // do we have to set this ?
                //setDateTime(Year, Month, Day, Hours, Minutes, Seconds);


                // Process Join request, only parse in join request mode
                if(joinReqFlag == 1)                                   // Device enables this flag
                {
                    // Parse Network ID
                    j = 0;
                    k = 0;
                    memset(rArrayBuff, NULL, 6);
                    for(j=8; j<=11; j++)
                    {
                        rArrayBuff[k++] = recvMessage.message[j];
                    }
                    networkID = atoi(rArrayBuff);

                    // get time for each slot
                    j = 0;
                    k = 0;
                    memset(rArrayBuff, NULL, 6);
                    for(j=14; j<=16; j++)
                    {
                        rArrayBuff[k++] = recvMessage.message[j];
                    }

                    // Store slot time
                    recvMessage.rSlotTime = atoi(rArrayBuff);

                    // get access slot time, from sync message
                    getAccessSlot();

                }

            }
            else
            {
                syncMesFlag = 0;

            }
        }
    }
    else
    {
        // store each byte to receive message buffer, global structure fined in comm.h, (check length of buffer)
        recvMessage.message[i++] = c;

    }

}


void receiveMessage(void)
{

    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;
    UART1_IM_R = UART_IM_RXIM;                       // turn-on RX interrupt
    NVIC_EN0_R |= 1 << (INT_UART1-16);               // turn-on interrupt 22 (UART1)


}




// Blocking Function for sending Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3)
// retval : none
// args   : Character Data (8-BIT) value
void sendData(const char data)
{
    while(UART1_FR_R & UART_FR_TXFF);
        UART1_DR_R = data;
}




// Blocking Function for sending Stream of Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3), with checksum
// retval : none
// args   : Data Stream / String value
void sendStream(char* data)
{
    uint8_t i        = 0;
    uint8_t len      = 0;
    uint8_t checksum = 0;

    len = strlen(data);                                                           // Calculate length of data string

    // Calculate Checksum
    for(i=0; i<len; i++)
        checksum = data[i] + ((checksum & 0xFF) + ((checksum >> 8) & 0xFF)) ;    // Avoid overflow from 8 bit, (Idea from RFC 1071.)

    data[i] = checksum;
    data[i+1] = 0;

    // Send Data
    for(i=0; i<len + 2; i++)
        sendData(data[i]);


}



// Function for Receiving data from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Character Data (8-Bit)
// args   : none
char recvData(void)
{
    while(UART1_FR_R & UART_FR_RXFE);
        return UART1_DR_R & 0xFF;;
}



// Function for Receiving data stream from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Signed Integer (8-Bit), 0: Success, -1: Fail, Checksum Error, -2: Timeout, no message received
// args   : String buffer to store data.
int8_t recvStream(char* buffer)
{
    char dataInput = 0;
    uint8_t i = 0;
    uint8_t j = 0;
    uint8_t len = 0;

    uint8_t checksum = 0;

    while(1)
    {
        dataInput = recvData();

       if(dataInput == 10)
           break;

       else
           buffer[i++] = dataInput;

       if(timeoutUpdate == 1)
           break;

    }

    len = strlen(buffer);

    // Check for Checksum Error
    for(j=0; j<len-1; j++)                                                                 // len - 1 for postion of checksum value
        checksum = buffer[j] + ((checksum & 0xFF) + ((checksum >> 8) & 0xFF)) ;            // Avoid overflow from 8 bit

    checksum = (char)checksum;

    if(checksum != buffer[len-1])                                                         // Generate Error with checksum
        return -1;

    if(timeoutUpdate == 1)
        return -2;

    return 0;
}



