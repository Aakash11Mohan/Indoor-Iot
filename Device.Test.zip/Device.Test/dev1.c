//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : dev1.c                                                     //
// Author          : Aditya Mall                                                //
// Date            : 03/17/2019                                                 //
// Copyright       : (c) 2019, Aditya Mall, Mentor: Dr. Jason Losh,             //
//                   The University of Texas at Arlington.                      //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         :                                                            //
// Version Control : GIT                                                        //
//                                                                              //
// Hardware configuration:                                                      //
//                                                                              //
//                                                                              //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// This Software was made by Aditya Mall, under the guidance of Dr. Jason Losh, //
// The University of Texas at Arlington. Any UNAUTHORIZED use of this software, //
// without the prior permission and consent of Dr. Jason Losh or any of the,    //
// mentioned contributors is a direct violation of Copyright.                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
// For more info please contact: aditya.mall@mavs.uta.edu                       //
//                                                                              //
//******************************************************************************//



//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//

#include <tm4c123gh6pm.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include "comms.h"
#include "rtctime.h"


//*****************************************************************************//
//                                                                             //
//                 MACRO DEFINITIONS, DIRECTIVES and STRUCTURES                //
//                                                                             //
//*****************************************************************************//


//****************** Bit Banding defines for Pins *********************//      (for TM4C123GXL-TIVA-C LAUNCHPAD)

//Port F
#define PF1               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 1*4)))
#define PF2               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 2*4)))
#define PF3               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 3*4)))
#define PF4               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 4*4)))



//***************************** Board Modules Pins *************************// (for TM4C123GXL-TIVA-C LAUNCHPAD)

#define ONBOARD_RED_LED           PF1
#define ONBOARD_BLUE_LED          PF2
#define ONBOARD_GREEN_LED         PF3
#define ONBOARD_PUSH_BUTTON       PF4





//*****************************************************************************//
//                                                                             //
//                          Function Prototypes                                //
//                                                                             //
//*****************************************************************************//

void initHw();
void joinRequest(void);
void joinMessageSend(void);


//*****************************************************************************//
//                                                                             //
//                          GLOBAL VARIABLES                                   //
//                                                                             //
//*****************************************************************************//

typedef struct joinRequest
{
    uint8_t PREAMBLE[4];
    uint8_t NID[4];
    uint8_t MAC[6];
    uint8_t SLOT[2];

}joinRequestType;




// local buffer for storing values and sending to uart
char joinMessageBuffer[sizeof(joinRequestType) + 2];


uint8_t slotNumber = 1;
uint16_t slotTime = 1;


// Join request variables
uint16_t networkId = 0;                         // get from sync message
uint8_t  slotsReq  = 1;


char arrayBuffer[6] = {0};

//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//

void initHw()
{
    //******************************************************* Clock Configs ******************************************************************//

    // Configure System clock as 40Mhz
    SYSCTL_RCC_R = SYSCTL_RCC_XTAL_16MHZ | SYSCTL_RCC_OSCSRC_MAIN | SYSCTL_RCC_USESYSDIV | (0x04 << SYSCTL_RCC_SYSDIV_S);

    // Enable GPIO port A, and F peripherals
    SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOA | SYSCTL_RCGC2_GPIOF | SYSCTL_RCGC2_GPIOC;



    //**************************************************** On Board Modules ******************************************************************//

    // Configure On boards RED, GREEN and BLUE led and Pushbutton Pins
    GPIO_PORTF_DEN_R |= (1 << 1) | (1 << 2) | (1 << 3) | (1 << 4);                  // Enable Digital
    GPIO_PORTF_DIR_R |= (1 << 1) | (1 << 2) | (1 << 3);                             // Enable as Output
    GPIO_PORTF_DIR_R &= ~(0x10);                                                    // Enable push button as Input
    GPIO_PORTF_PUR_R |= 0x10;                                                       // Enable internal pull-up for push button

}


void waitMicrosecond(uint32_t us)
{
    __asm("WMS_LOOP0:   MOV  R1, #6"       );
    __asm("WMS_LOOP1:   SUB  R1, #1"       );
    __asm("             CBZ  R1, WMS_DONE1");
    __asm("             NOP"               );
    __asm("             NOP"               );
    __asm("             B    WMS_LOOP1"    );
    __asm("WMS_DONE1:   SUB  R0, #1"       );
    __asm("             CBZ  R0, WMS_DONE0");
    __asm("             NOP"               );
    __asm("             B    WMS_LOOP0"    );
    __asm("WMS_DONE0:"                     );
}



// part of comms driver
//void initWTimer5(void)
//{
//    SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R5;                                   // turn-on timer
//    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;                                              // turn-off counter before reconfiguring
//    WTIMER5_CFG_R  = 4;                                                            // configure as 32-bit counter (A only)
//    WTIMER5_TAMR_R = TIMER_TAMR_TAMR_PERIOD | TIMER_TAMR_TACDIR;                   // configure for edge time mode, count up
//    WTIMER5_TAILR_R = 40000 - 1;                                                   // 1ms
//    WTIMER5_CTL_R |= TIMER_CTL_TAEN;                                               // enable timer A
//    WTIMER5_IMR_R = TIMER_IMR_TATOIM;                                              // timeout mode interrupt enable
//    NVIC_EN3_R |= 1 << (INT_WTIMER5A-16-96);                                       // enable interrupt in nvic
//
//}


void initWTimer5(void)
{
    SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R5;                                       // turn-on timer
    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;                                                  // turn-off counter before reconfiguring
    WTIMER5_CFG_R  = 4;                                                                // configure as 32-bit counter (A only)

    WTIMER5_TAMR_R = TIMER_TAMR_TAMR_1_SHOT | TIMER_TAMR_TACDIR | TIMER_TAMR_TAMIE;    // 1-Shot mode, Count up, Match interrupt Enable
    WTIMER5_TAMATCHR_R = (40000 - 1) * (slotTime * slotNumber);                        // Initial Match load value before sync, get from EEPROM, given by server

    NVIC_EN3_R |= 1 << (INT_WTIMER5A-16-96);                                           // Enable interrupt in NVIC
    WTIMER5_IMR_R = TIMER_IMR_TAMIM;                                                   // Match Interrupt Enable

    WTIMER5_CTL_R |= TIMER_CTL_TAEN; //start
}


uint32_t delay;

// local device guys
void wTimer5Isr(void)
{

    //receiveMessage();

    setDateTime(Year, Month, Day, Hours, Minutes, Seconds);

    getDateTime();

    if(AslotRecvd == 1 && syncMesFlag == 1)
    {
        joinMessageSend();

        joinReqFlag = 0;

        ONBOARD_BLUE_LED  ^= 1;
        ONBOARD_GREEN_LED ^= 1;
        ONBOARD_RED_LED  = 0;
    }




    WTIMER5_ICR_R = TIMER_ICR_TAMCINT;
    WTIMER5_TAV_R = 0;

}

void joinRequest(void)
{
    while(ONBOARD_PUSH_BUTTON);

    joinReqFlag = 1;

}

void joinMessageSend(void)
{

    joinRequestType joinRequest;

    joinReqFlag = 0;

    // Preamble
    joinRequest.PREAMBLE[0] = 0xAA;
    joinRequest.PREAMBLE[1] = 0xAA;
    joinRequest.PREAMBLE[2] = 0xCC;
    joinRequest.PREAMBLE[3] = 0xCC;

    // Slot Number


    // IOT network to join, get from sync message
    memset(arrayBuffer, NULL, 6);
    networkId = networkID;
    ltoa(networkId, arrayBuffer);
    memcpy(joinRequest.NID, arrayBuffer, sizeof(arrayBuffer));


    // MAC Address
    joinRequest.MAC[0] =0x84;
    joinRequest.MAC[1] =0x48;
    joinRequest.MAC[2] =0xFF;
    joinRequest.MAC[3] =0x6A;
    joinRequest.MAC[4] =0x67;
    joinRequest.MAC[4] =0xBC;


    // Number of slots requested
    memset(arrayBuffer, NULL, sizeof(arrayBuffer));
    if(slotsReq < 10)
    {
        arrayBuffer[0] = '0';
        arrayBuffer[1] = slotsReq + 48;
    }
    else
    {
        ltoa(slotsReq, arrayBuffer);
    }
    memcpy(joinRequest.SLOT,arrayBuffer,sizeof(arrayBuffer));



    // Store all details to buffer and send message (check size of this global buffer before sending)
    memset(joinMessageBuffer, NULL, sizeof(joinMessageBuffer));
    memcpy(joinMessageBuffer, &joinRequest, sizeof(joinRequest));
    sendStream(joinMessageBuffer);


}


// Main receiver message, every toggle means two message receive sequence
int main(void)
{

    initHw();          // Initialize Hardware, local to device guys

    initComm();        // Initialize Comms Module, comes with comms driver

    initWTimer5();     // Intialize widetimer ISR, functions comes with comms driver

    initRTC();

    setDateTime(2030, 10, 26, 19, 10, 19);

    while(1)
    {
        joinRequest();






    }

    //return 0;
}
