//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : rtctime.h                                                  //
// Date            : 03/25/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         :                                                            //
// Version Control : GIT                                                        //
//                                                                              //
// Hardware configuration:                                                      //
//                                                                              //
//                                                                              //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//                                                                              //
//******************************************************************************//


#ifndef __RTCTIME_H
#define __RTCTIME_H


//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//


#include <tm4c123gh6pm.h>
#include <stdint.h>



//*****************************************************************************//
//                                                                             //
//                          GLOBAL VARIABLES                                   //
//                                                                             //
//*****************************************************************************//


#pragma pack(1)

struct rtcTime
{
    char tHead;

    uint8_t hours;

    uint8_t minutes;

    uint8_t seconds;


}time;


#pragma pack(1)

struct rtcDate
{
    char dHead;

    uint8_t year;

    uint8_t month;

    uint8_t day;


}date;


//*****************************************************************************//
//                                                                             //
//                          Function Prototypes                                //
//                                                                             //
//*****************************************************************************//


// Function for Initializing Real-Time Clock
// retval : Time in seconds
// args   : 6 arguments, value of year, month, day, hours, minutes, seconds
void initRTC(void);


// Function for setting Time and Date
// retval : Time in seconds
// args   : 6 arguments, value of year, month, day, hours, minutes, seconds
struct rtcTime getDateTime(void);


// Function for reading time
// retval : Value of "time" Data Strcuture declared in header file
// args   : none
uint32_t setDateTime(uint16_t year, uint8_t month, uint8_t days, uint8_t hours, uint8_t minutes, uint8_t seconds);


#endif

