//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : link1.c                                                    //
// Date            : 03/22/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         :                                                            //
// Version Control : GIT                                                        //
//                                                                              //
// Hardware configuration:                                                      //
//                                                                              //
//                                                                              //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//                                                                              //
//******************************************************************************//




//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//


#include "comms.h"
#include <tm4c123gh6pm.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "rtctime.h"


//*****************************************************************************//
//                                                                             //
//                 MACRO DEFINITIONS, DIRECTIVES and STRUCTURES                //
//                                                                             //
//*****************************************************************************//


//****************** Bit Banding defines for Pins *********************//      (for TM4C123GXL-TIVA-C LAUNCHPAD)

//Port F
#define PF1               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 1*4)))
#define PF2               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 2*4)))
#define PF3               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 3*4)))
#define PF4               (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 4*4)))



//***************************** Board Modules Pins *************************// (for TM4C123GXL-TIVA-C LAUNCHPAD)

#define ONBOARD_RED_LED           PF1
#define ONBOARD_BLUE_LED          PF2
#define ONBOARD_GREEN_LED         PF3
#define ONBOARD_PUSH_BUTTON       PF4


//*****************************************************************************//
//                                                                             //
//                          Function Prototypes                                //
//                                                                             //
//*****************************************************************************//

void initHw();
void syncMessageSend(void);

//*****************************************************************************//
//                                                                             //
//                          GLOBAL VARIABLES                                   //
//                                                                             //
//*****************************************************************************//




// SyncMessage
typedef struct syncMessage
{
    uint8_t PREAMBLE[4];
    uint8_t SLOTNUM[2];
    uint8_t LENGTH[2];
    uint8_t NID[4];
    uint8_t NSLOT[2];
    uint8_t TSLOT[3];
    uint8_t BSLOT[2];
    uint8_t ASLOT[2];
    uint8_t TIME[6];
    uint8_t DATE[6];

}syncMessageType;




struct localTime
{
    char hours[2];

    char minutues[2];

    char sec[2];

    char pad;


}LTIME;


struct localDate
{
    char year[2];

    char month[2];

    char day[2];

    char pad;


}LDATE;



// local buffer for storing values and sending to uart
char syncMessageBuffer[sizeof(syncMessageType) + 2];



// Sync Generator / Server Variables
uint8_t  slotNumber = 1;                      // Slot Number of server/ sync generator                        fixed

// Sync Message Body Variables
uint8_t  length        = 0;                   // Length of message body                                       variable?
uint16_t networkId     = 8118;                // Network ID, predefined and unique for every system,          fixed
uint8_t  numOfSlots    = 3;                   // Total Number of Slots, Gets from the EEPROM                  variable
uint16_t slotTime      = 100;                 // Time of each slot?,                                          fixed
uint8_t  broadcastSlot = 3;                   // Slot Number of Broadcast slot,                               fixed
uint8_t  accessSlot    = 2;                   // Slot Number of Access Slot,                                  fixed



uint8_t NSLOT = 11;
uint16_t TSLOT = 100;


char numBuff[6] = {0};

//*****************************************************************************//
//                                                                             //
//                      FUNCTIONS AND SUBROUTINES                              //
//                                                                             //
//*****************************************************************************//

void initHw()
{
    //******************************************************* Clock Configs ******************************************************************//

    // Configure System clock as 40Mhz
    SYSCTL_RCC_R = SYSCTL_RCC_XTAL_16MHZ | SYSCTL_RCC_OSCSRC_MAIN | SYSCTL_RCC_USESYSDIV | (0x04 << SYSCTL_RCC_SYSDIV_S);

    // Enable GPIO port A, and F peripherals
    SYSCTL_RCGC2_R |= SYSCTL_RCGC2_GPIOA | SYSCTL_RCGC2_GPIOF | SYSCTL_RCGC2_GPIOC;



    //**************************************************** On Board Modules ******************************************************************//

    // Configure On boards RED, GREEN and BLUE led and Pushbutton Pins
    GPIO_PORTF_DEN_R |= (1 << 1) | (1 << 2) | (1 << 3) | (1 << 4);                  // Enable Digital
    GPIO_PORTF_DIR_R |= (1 << 1) | (1 << 2) | (1 << 3);                             // Enable as Output
    GPIO_PORTF_DIR_R &= ~(0x10);                                                    // Enable push button as Input
    GPIO_PORTF_PUR_R |= 0x10;                                                       // Enable internal pull-up for push button

}

//void initWTimer5(void)
//{
//    SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R5;                                   // turn-on timer
//    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;                                              // turn-off counter before reconfiguring
//    WTIMER5_CFG_R  = 4;                                                            // configure as 32-bit counter (A only)
//    WTIMER5_TAMR_R = TIMER_TAMR_TAMR_PERIOD | TIMER_TAMR_TACDIR;                   // configure for edge time mode, count up
//    WTIMER5_TAILR_R = (40000 - 1) * 100;                                           // 100ms
//    WTIMER5_CTL_R |= TIMER_CTL_TAEN;                                               // enable timer A
//    WTIMER5_IMR_R = TIMER_IMR_TATOIM;                                              // timeout mode interrupt enable
//    NVIC_EN3_R |= 1 << (INT_WTIMER5A-16-96);                                       // enable interrupt in nvic
//
//}


//void wTimer5Isr(void)
//{
//
//        syncMessageSend();
//
//
//        ONBOARD_GREEN_LED ^= 1;
//
//
//    WTIMER5_ICR_R = TIMER_ICR_TATOCINT;
//
//}



// match timer
void initWTimer5(void)
{
    SYSCTL_RCGCWTIMER_R |= SYSCTL_RCGCWTIMER_R5;                                       // turn-on timer
    WTIMER5_CTL_R &= ~TIMER_CTL_TAEN;                                                  // turn-off counter before reconfiguring
    WTIMER5_CFG_R  = 4;                                                                // configure as 32-bit counter (A only)

    WTIMER5_TAMR_R = TIMER_TAMR_TAMR_1_SHOT | TIMER_TAMR_TACDIR | TIMER_TAMR_TAMIE;    // 1-Shot mode, Count up, Match interrupt Enable
    WTIMER5_TAMATCHR_R = (40000 - 1) * (slotTime * numOfSlots);                        //

    NVIC_EN3_R |= 1 << (INT_WTIMER5A-16-96);                                           // Enable interrupt in NVIC
    WTIMER5_IMR_R = TIMER_IMR_TAMIM;                                                   // Match Interrupt Enable

    WTIMER5_CTL_R |= TIMER_CTL_TAEN; //start
}


// match ISR
void wTimer5Isr(void)
{

    syncMessageSend();

    ONBOARD_GREEN_LED ^= 1;


    WTIMER5_ICR_R = TIMER_ICR_TAMCINT;
    WTIMER5_TAV_R = 0;

}



// micro second delay function
void waitMicrosecond(uint32_t us)
{
    __asm("WMS_LOOP0:   MOV  R1, #6"       );
    __asm("WMS_LOOP1:   SUB  R1, #1"       );
    __asm("             CBZ  R1, WMS_DONE1");
    __asm("             NOP"               );
    __asm("             NOP"               );
    __asm("             B    WMS_LOOP1"    );
    __asm("WMS_DONE1:   SUB  R0, #1"       );
    __asm("             CBZ  R0, WMS_DONE0");
    __asm("             NOP"               );
    __asm("             B    WMS_LOOP0"    );
    __asm("WMS_DONE0:"                     );
}




void syncMessageSend(void)
{


    syncMessageType sync;


    // Preamble
    sync.PREAMBLE[0] = 0xAA;
    sync.PREAMBLE[1] = 0xAA;
    sync.PREAMBLE[2] = 0x55;
    sync.PREAMBLE[3] = 0x55;


    // Slot Number
    memset(numBuff, NULL, sizeof(numBuff));
    if(slotNumber < 10)
    {
        numBuff[0] = '0';
        numBuff[1] = slotNumber + 48;
    }
    else
    {
        ltoa(slotNumber, numBuff);
    }
    memcpy(sync.SLOTNUM,numBuff,sizeof(sync.SLOTNUM));


    // Length
    memset(numBuff, NULL, sizeof(numBuff));
    length = sizeof(syncMessageBuffer);
    ltoa(length, numBuff);
    memcpy(sync.LENGTH,numBuff,sizeof(sync.LENGTH));



    // NID
    memset(numBuff, NULL, sizeof(numBuff));
    ltoa(networkId ,numBuff);
    memcpy(sync.NID,numBuff,sizeof(sync.NID));



    // NUM OF SLOT
    memset(numBuff, NULL, sizeof(numBuff));
    if(numOfSlots < 10)
    {
        numBuff[0] = '0';
        numBuff[1] = numOfSlots + 48;
    }
    else
    {
        ltoa(numOfSlots, numBuff);
    }
    memcpy(sync.NSLOT,numBuff,sizeof(numBuff));


    // Time of Slot
    memset(numBuff, NULL, sizeof(numBuff));
    ltoa(slotTime, numBuff);
    memcpy(sync.TSLOT, numBuff, sizeof(numBuff));


    // Broadcast Slot
    memset(numBuff, NULL, sizeof(numBuff));
    if(broadcastSlot < 10)
    {
        numBuff[0] = '0';
        numBuff[1] = broadcastSlot + 48;
    }
    else
    {
        ltoa(broadcastSlot, numBuff);
    }
    memcpy(sync.BSLOT,numBuff,sizeof(numBuff));


    // Access Slot
    memset(numBuff, NULL, sizeof(numBuff));
    if(accessSlot < 10)
    {
        numBuff[0] = '0';
        numBuff[1] = accessSlot + 48;
    }
    else
    {
        ltoa(accessSlot, numBuff);
    }
    memcpy(sync.ASLOT,numBuff,sizeof(numBuff));


    //***********************TIME**********************//
    getDateTime();

    memset(&LTIME, NULL, sizeof(LTIME));

    if(time.hours < 10)
    {
        LTIME.hours[0] = 48;
        LTIME.hours[1] = time.hours + 48;
    }
    else
        ltoa(time.hours, LTIME.hours);

    if(time.minutes < 10)
    {
        LTIME.minutues[0] = 48;
        LTIME.minutues[1] = time.minutes + 48;
    }
    else
        ltoa(time.minutes, LTIME.minutues);

    if(time.seconds < 10)
    {
        LTIME.sec[0] = 48;
        LTIME.sec[1] = time.seconds + 48;
    }
    else
        ltoa(time.seconds, LTIME.sec);

    memcpy(sync.TIME, &LTIME, sizeof(LTIME));

    //*************************DATE*********************//

    memset(&LDATE, NULL, sizeof(LDATE));

    if(date.year < 10)
    {
        LDATE.year[0] = 48;
        LDATE.year[1] = date.year + 48;
    }
    else
        ltoa(date.year, LDATE.year);

    if(date.month < 10)
    {
        LDATE.month[0] = 48;
        LDATE.month[1] = date.month  + 48;
    }
    else
        ltoa(date.month, LDATE.month);

    if(date.day < 10)
    {
        LDATE.day[0] = 48;
        LDATE.day[1] = date.day + 48;
    }
    else
        ltoa(date.day, LDATE.day);


    memcpy(sync.DATE, &LDATE, sizeof(LDATE));



    // Store all details to buffer and send message (check size of this global buffer before sending)
    memset(syncMessageBuffer, NULL, sizeof(syncMessageBuffer));
    memcpy(syncMessageBuffer, &sync, sizeof(sync));
    sendStream(syncMessageBuffer);

}




// Sender - Broadcast
int main(void)
{

    initHw();    //Initialize Hardware

    initComm();  // Initialize Communication Module

    initWTimer5();

    initRTC();

    setDateTime(2019, 10, 19, 19, 10, 0);

    while(1)
    {



    }

    //return 0;
}
