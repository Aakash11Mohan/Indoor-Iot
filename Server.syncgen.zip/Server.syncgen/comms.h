//******************************************************************************//
// INFO                                                                         //
//******************************************************************************//
// File            : comms.h                                                    //
// Date            : 03/22/2019                                                 //
// Project         : IOT                                                        //
// Target Platform : EK-TM4C123GXL Evaluation Board                             //
// Target uC       : TM4C123GH6PM                                               //
// IDE             : Code Composer Studio v7                                    //
// System Clock    : 40 MHz                                                     //
// UART Baudrate   : 115200                                                     //
// Data Length     : 8 Bits                                                     //
// Version         : 1.0                                                        //
// Version Control : GIT                                                        //
//                                                                              //
//******************************************************************************//
// ATTENTION                                                                    //
//******************************************************************************//
//                                                                              //
// This Software was made under the guidance of Dr. Jason Losh,                 //
// The University of Texas at Arlington. Any UNAUTHORIZED use of this software, //
// without the prior permission and consent of Dr. Jason Losh or any of the,    //
// mentioned contributors is a direct violation of Copyright.                   //
//                                                                              //
// THIS SOFTWARE IS PROVIDED "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED   //
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF           //
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. //
// ADITYA MALL OR ANY MENTIONED CONTRIBUTORS SHALL NOT, IN ANY CIRCUMSTANCES,   //
// BE LIABLE FOR SPECIAL, INCIDENTAL,OR CONSEQUENTIAL DAMAGES,                  //
// FOR ANY REASON WHATSOEVER.                                                   //
//                                                                              //
//******************************************************************************//


#ifndef __COMMS_H
#define __COMMS_H


//*****************************************************************************//
//                                                                             //
//              STANDARD LIBRARIES AND BOARD SPECIFIC HEADER FILES             //
//                                                                             //
//*****************************************************************************//

#include <tm4c123gh6pm.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "rtctime.h"



struct uartRecv
{
    char message[35];
    uint8_t checksum;

    uint8_t rSlotNum;
    uint16_t rSlotTime;

}recvMessage;


// Message variables
extern uint16_t networkID;

extern uint8_t Hours;
extern uint8_t Minutes;
extern uint8_t Seconds;

extern uint8_t Year;
extern uint8_t Month;
extern uint8_t Day;



// Flags
extern uint8_t syncMesFlag;
extern uint8_t joinReqFlag;          // Flag for join request enable

//*****************************************************************************//
//                                                                             //
//                          Function Prototypes                                //
//                                                                             //
//*****************************************************************************//


// Function for Initialing Communication module
// retval : none
// args   : none
void initComm(void);


// Blocking Function for sending Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3)
// retval : none
// args   : Character Data (8-BIT) value
void sendData(const char data);


// Blocking Function for sending Stream of Data through UART TX port (PC5) connected to DIN/CONFIG at XBee module (Pin 3), with checksum.
// retval : none
// args   : Data Stream / String value
void sendStream(char* data);


// Function for Receiving data from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Character Data (8-Bit)
// args   : none
char recvData(void);


// Function for Receiving data stream from UART RX port (PC4) connected to DOUT at XBee module (Pin 2)
// retval : Signed Integer (8-Bit), 0: Success, -1: Fail, Checksum Error
// args   : String buffer to store data.
int8_t recvStream(char* buffer);

void receiveMessage(void);

#endif

